# Cinema Wall artwork

Created with the built-in image-generation tool from the selected 01 / Cinema Wall mockup.

Prompt: Edit the selected Cinema Wall concept into a clean background asset for a real HTML website. Preserve the five large staggered fictional movie posters and their cinematic imagery: astronaut, rainy romantic couple, desert explorer, noir detective, woodland creature. Preserve poster titles and black gutters. Remove the website brand, caption, navigation, search icon, headline, subheading, buttons, and genre thumbnails. Fill removed regions by extending the full-height poster imagery. Landscape 16:9; bright visible posters; no website UI. The developer adds gradients, text, and controls in HTML/CSS.

Saved asset: static/cinema-wall.png. The fictional poster artwork illustrates the design and is not the MovieLens catalog.
