# MovieMatch login screen — Flask and PyCharm

A small, commented example for your movie recommender. This adds account registration and login. Your MiniLM recommender is not connected yet.

The selected Cinema Wall design uses a black-and-red theme and original movie poster artwork. Welcome, login, sign-up, and the signed-in page share this design. Restart the app in PyCharm after changing templates, then refresh your browser.

## Run in PyCharm

1. Extract the ZIP, then open the `movie-login-demo` folder in PyCharm.
2. Select a Python interpreter for the project (Python 3.12 works).
3. Open PyCharm's Terminal and run `python -m pip install -r requirements.txt`.
4. Right-click `app.py` and choose **Run 'app'**, or run `python app.py` in the terminal.
5. Open http://127.0.0.1:5000 in your browser.

Keep `app.py` and the `templates` folder together. Flask finds the HTML inside `templates` automatically.

## What each file does

- `app.py`: Python code that creates accounts, checks passwords, and controls pages.
- `templates/page.html`: The screens and their colors, fields, buttons, and explanatory comments.
- `static/cinema.css`: The Cinema Wall layout, colors, and phone-size adjustments.
- `static/cinema-wall.png`: Original generated movie poster artwork used behind the real HTML controls.
- `requirements.txt`: The one package to install: Flask. SQLite is included with Python; Werkzeug comes with Flask.
- `users.db`: Created automatically when the app starts. Keeps registered users after a restart.
- `.session_secret`: Created automatically. Signs session cookies; keep it private and do not upload it to GitHub.

## Follow the code

`@app.route` connects a web address to a Python function. A GET request displays a page. A POST request sends a completed form to Python. `request.form` reads the fields, `render_template` displays the HTML, and `redirect` takes the user to another page.

The sign-up function compares `password` and `confirmation`. If they differ, the account is not created. Passwords must be 8–128 characters. Usernames must be 3–100 characters. An email address can be used as the username; this example does not verify email ownership or send email.

The database rejects duplicate usernames without regard to ASCII letter case. `generate_password_hash` stores a protected representation of the password. `check_password_hash` checks a login attempt against that stored value. The confirmation password is never stored.

The `session` remembers the logged-in user through a signed browser cookie. The home page checks that session before displaying itself. Signing out clears it. The hidden `form_token` prevents form submissions that did not originate with the current browser session.

Flask's HTML template escapes the username when displaying it. SQL `?` placeholders safely pass form values to the database.

## Try it

Open the welcome page, click Sign Up, and enter two different passwords. You should see a mismatch error. Then enter matching passwords, create an account, and log in. Try a wrong password and a duplicate username too. After logging out, visiting `/home` sends you back to Log In.

## Next step

Connect your recommendation function inside the `home()` route and display its results in the home section of `page.html`. This example is a browser login interface, not a JSON API or a complete recommendation app. A new account ID is not automatically one of the 600 MovieLens users; favorites-based recommendations are an appropriate starting point for new accounts.

This is a local learning app. Before public deployment, add login rate limiting, use HTTPS with secure cookies, and run a production server instead of Flask's development server.

Reference: https://flask.palletsprojects.com/en/stable/tutorial/views/
